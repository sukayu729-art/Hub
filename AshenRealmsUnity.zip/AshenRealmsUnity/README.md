# Ashen Realms — Unity RPG

A small, playable 3D RPG prototype for Unity 6. It creates its arena, player, enemies, lighting, camera, and HUD at runtime, so no imported art assets are required.

## Requirements
- Unity 6 (6000.0 LTS or newer)
- Windows, macOS, or Linux editor
- Built-in 3D physics

## Open and run
1. Create a new **3D Core** Unity project named `AshenRealms`.
2. Close Unity.
3. Copy this package's `Assets/AshenRealms` folder into the project's `Assets` folder.
4. Reopen the project.
5. Create an empty GameObject named `GameBootstrap`.
6. Add the `RPGGameBootstrap` component to it.
7. In **Edit > Project Settings > Player > Other Settings**, set **Active Input Handling** to **Both** or **Input Manager (Old)**. Restart the editor if prompted.
8. Press Play.

## Controls
- `W A S D`: move
- Mouse: rotate camera
- Left mouse button or `Space`: attack
- `E`: interact with the nearest quest marker
- `I`: toggle inventory panel
- `Escape`: unlock mouse cursor

## Gameplay loop
Defeat Slimes for EXP and gold, interact with the blue quest crystal, level up, and collect drops. Player health regenerates slowly out of combat. Enemies respawn after a delay.

## Build a Windows executable
1. Open **File > Build Profiles**.
2. Add **Windows** as an active platform if needed.
3. Add the current scene to **Scene List**.
4. Choose **Build** and select an output folder.

## Project layout
- `Assets/AshenRealms/Scripts/Config/GameConfig.cs`: tunable gameplay constants.
- `Assets/AshenRealms/Scripts/Core/RPGGameBootstrap.cs`: runtime scene assembly and dependency wiring.
- `Assets/AshenRealms/Scripts/Player/PlayerController.cs`: movement and camera-relative input.
- `Assets/AshenRealms/Scripts/Combat/CombatSystem.cs`: player attacks and damage interface.
- `Assets/AshenRealms/Scripts/Enemies/EnemyController.cs`: enemy AI, health, respawn, and rewards.
- `Assets/AshenRealms/Scripts/Systems/RPGProgression.cs`: XP, leveling, gold, inventory, and quest state.
- `Assets/AshenRealms/Scripts/UI/RPGUI.cs`: HUD and interaction prompts.

## Modify gameplay
Edit values in `GameConfig.cs`; combat, progression, AI, and UI are independent modules. The bootstrap assembles references and can be replaced with authored scenes later.
