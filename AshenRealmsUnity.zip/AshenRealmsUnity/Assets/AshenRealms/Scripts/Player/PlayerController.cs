using UnityEngine;

namespace AshenRealms
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class PlayerController : MonoBehaviour
    {
        [SerializeField] private Transform cameraPivot;
        private CharacterController controller;
        private float verticalVelocity;
        private float cameraYaw;
        private float cameraPitch = 12f;
        private RPGProgression progression;

        public Transform CameraPivot => cameraPivot;

        public void Initialize(RPGProgression playerProgression, Transform pivot)
        {
            progression = playerProgression;
            cameraPivot = pivot;
            controller = GetComponent<CharacterController>();
        }

        private void Start()
        {
            if (controller == null) controller = GetComponent<CharacterController>();
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        private void Update()
        {
            if (controller == null) return;
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            if (Cursor.lockState != CursorLockMode.Locked && Input.GetMouseButtonDown(1))
            {
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }

            UpdateCamera();
            MovePlayer();

            if (progression != null && progression.CurrentHealth > 0f)
                progression.Heal(GameConfig.PlayerHealthRegenPerSecond * Time.deltaTime);
        }

        private void UpdateCamera()
        {
            if (Cursor.lockState != CursorLockMode.Locked) return;
            cameraYaw += Input.GetAxis("Mouse X") * GameConfig.CameraSensitivity;
            cameraPitch -= Input.GetAxis("Mouse Y") * GameConfig.CameraSensitivity;
            cameraPitch = Mathf.Clamp(cameraPitch, -12f, 48f);
            transform.rotation = Quaternion.Euler(0f, cameraYaw, 0f);
            if (cameraPivot != null)
                cameraPivot.rotation = Quaternion.Euler(cameraPitch, cameraYaw, 0f);
        }

        private void MovePlayer()
        {
            float horizontal = Input.GetAxisRaw("Horizontal");
            float vertical = Input.GetAxisRaw("Vertical");
            Vector3 input = new Vector3(horizontal, 0f, vertical).normalized;
            Vector3 move = transform.TransformDirection(input) * GameConfig.PlayerMoveSpeed;

            if (controller.isGrounded && verticalVelocity < 0f)
                verticalVelocity = -2f;
            verticalVelocity += Physics.gravity.y * Time.deltaTime;
            move.y = verticalVelocity;
            controller.Move(move * Time.deltaTime);
        }
    }
}
