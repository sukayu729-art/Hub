using UnityEngine;

namespace AshenRealms
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class EnemyController : MonoBehaviour, IDamageable
    {
        private CharacterController controller;
        private RPGProgression progression;
        private Transform player;
        private float health;
        private float nextAttackTime;
        private float respawnAt;
        private Vector3 spawnPosition;
        private Renderer bodyRenderer;
        private bool defeated;

        public bool IsAlive => !defeated && health > 0f;

        public void Initialize(Transform playerTransform, RPGProgression playerProgression)
        {
            player = playerTransform;
            progression = playerProgression;
            controller = GetComponent<CharacterController>();
            spawnPosition = transform.position;
            health = GameConfig.EnemyMaxHealth;
            bodyRenderer = GetComponentInChildren<Renderer>();
        }

        private void Update()
        {
            if (defeated)
            {
                if (Time.time >= respawnAt) Respawn();
                return;
            }
            if (player == null || progression == null) return;
            Vector3 delta = player.position - transform.position;
            delta.y = 0f;
            float distance = delta.magnitude;
            if (distance <= GameConfig.EnemyAggroRange && distance > GameConfig.EnemyAttackRange)
            {
                Vector3 direction = delta.normalized;
                transform.rotation = Quaternion.Slerp(transform.rotation,
                    Quaternion.LookRotation(direction), 8f * Time.deltaTime);
                controller.SimpleMove(direction * GameConfig.EnemyMoveSpeed);
            }
            else if (distance <= GameConfig.EnemyAttackRange && Time.time >= nextAttackTime)
            {
                nextAttackTime = Time.time + GameConfig.EnemyAttackCooldown;
                progression.SetHealth(progression.CurrentHealth - GameConfig.EnemyDamage);
            }
        }

        public void TakeDamage(float amount, GameObject source)
        {
            if (!IsAlive) return;
            health -= Mathf.Max(0f, amount);
            if (health <= 0f) Defeat();
            else
            {
                transform.localScale = Vector3.one * 0.92f;
                Invoke(nameof(ResetScale), 0.08f);
            }
        }

        private void ResetScale()
        {
            if (!defeated) transform.localScale = Vector3.one;
        }

        private void Defeat()
        {
            defeated = true;
            respawnAt = Time.time + GameConfig.EnemyRespawnSeconds;
            if (bodyRenderer != null) bodyRenderer.enabled = false;
            controller.enabled = false;
            progression.AddXP(GameConfig.XPPerEnemy);
            progression.AddGold(GameConfig.GoldPerEnemy);
            progression.RecordSlimeDefeat();
        }

        private void Respawn()
        {
            defeated = false;
            health = GameConfig.EnemyMaxHealth;
            transform.position = spawnPosition;
            transform.localScale = Vector3.one;
            controller.enabled = true;
            if (bodyRenderer != null) bodyRenderer.enabled = true;
        }
    }
}
