using System;
using System.Collections.Generic;
using UnityEngine;

namespace AshenRealms
{
    public sealed class RPGProgression : MonoBehaviour
    {
        public event Action Changed;
        public int Level { get; private set; } = 1;
        public int CurrentXP { get; private set; }
        public int Gold { get; private set; } = 25;
        public int Potions { get; private set; } = GameConfig.StartingPotionCount;
        public int SlimesDefeated { get; private set; }
        public bool QuestComplete { get; private set; }
        public bool QuestRewardClaimed { get; private set; }
        public float CurrentHealth { get; private set; } = GameConfig.PlayerMaxHealth;
        public float MaxHealth => GameConfig.PlayerMaxHealth + (Level - 1) * 12f;
        public int XPToNextLevel => 100 + (Level - 1) * 50;
        public IReadOnlyDictionary<string, int> Inventory => inventory;

        private readonly Dictionary<string, int> inventory = new Dictionary<string, int>
        {
            { "Slime Gel", 0 },
            { "Ancient Shard", 0 }
        };

        public void SetHealth(float value)
        {
            CurrentHealth = Mathf.Clamp(value, 0f, MaxHealth);
            Changed?.Invoke();
        }

        public void Heal(float amount)
        {
            SetHealth(CurrentHealth + amount);
        }

        public void AddXP(int amount)
        {
            CurrentXP += Mathf.Max(0, amount);
            while (CurrentXP >= XPToNextLevel)
            {
                CurrentXP -= XPToNextLevel;
                Level++;
                CurrentHealth = MaxHealth;
                Debug.Log("Level up! You reached level " + Level + ".");
            }
            Changed?.Invoke();
        }

        public void AddGold(int amount)
        {
            Gold = Mathf.Max(0, Gold + amount);
            Changed?.Invoke();
        }

        public void AddItem(string itemName, int amount)
        {
            if (!inventory.ContainsKey(itemName))
                inventory[itemName] = 0;
            inventory[itemName] += amount;
            Changed?.Invoke();
        }

        public void RecordSlimeDefeat()
        {
            SlimesDefeated++;
            AddItem("Slime Gel", 1);
            if (!QuestComplete && SlimesDefeated >= GameConfig.QuestSlimeGoal)
                QuestComplete = true;
            Changed?.Invoke();
        }

        public bool ClaimQuestReward()
        {
            if (!QuestComplete || QuestRewardClaimed)
                return false;
            QuestRewardClaimed = true;
            AddXP(GameConfig.QuestRewardXP);
            AddGold(GameConfig.QuestRewardGold);
            AddItem("Ancient Shard", 1);
            Changed?.Invoke();
            return true;
        }

        public bool UsePotion()
        {
            if (Potions <= 0 || CurrentHealth >= MaxHealth)
                return false;
            Potions--;
            Heal(GameConfig.PotionHealAmount);
            return true;
        }

        public bool BuyPotion()
        {
            if (Gold < GameConfig.PotionGoldCost)
                return false;
            Gold -= GameConfig.PotionGoldCost;
            Potions++;
            Changed?.Invoke();
            return true;
        }
    }
}
