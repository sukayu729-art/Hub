namespace AshenRealms
{
    public static class GameConfig
    {
        public const string GameTitle = "Ashen Realms";
        public const float PlayerMoveSpeed = 5.2f;
        public const float PlayerTurnSmoothTime = 0.08f;
        public const float CameraSensitivity = 2.2f;
        public const float CameraDistance = 6.5f;
        public const float CameraHeight = 2.4f;
        public const float PlayerMaxHealth = 100f;
        public const float PlayerAttackDamage = 25f;
        public const float PlayerAttackRange = 2.4f;
        public const float PlayerAttackCooldown = 0.55f;
        public const float EnemyMaxHealth = 60f;
        public const float EnemyDamage = 8f;
        public const float EnemyMoveSpeed = 2.0f;
        public const float EnemyAttackRange = 1.55f;
        public const float EnemyAggroRange = 10f;
        public const float EnemyAttackCooldown = 1.25f;
        public const float PlayerHealthRegenPerSecond = 1.8f;
        public const int XPPerEnemy = 25;
        public const int GoldPerEnemy = 8;
        public const float EnemyRespawnSeconds = 5f;
        public const int StartingPotionCount = 3;
        public const float PotionHealAmount = 45f;
        public const int PotionGoldCost = 15;
        public const int QuestRewardXP = 100;
        public const int QuestRewardGold = 50;
        public const int QuestSlimeGoal = 3;
    }
}
