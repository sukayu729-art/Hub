using UnityEngine;

namespace AshenRealms
{
    public sealed class RPGGameBootstrap : MonoBehaviour
    {
        [SerializeField] private bool buildOnAwake = true;
        [SerializeField] private int enemyCount = 5;
        [SerializeField] private float arenaRadius = 24f;

        private void Awake()
        {
            if (buildOnAwake) BuildWorld();
        }

        [ContextMenu("Rebuild World")]
        public void BuildWorld()
        {
            if (FindObjectOfType<PlayerController>() != null) return;
            CreateLighting();
            CreateGround();
            RPGProgression progression = new GameObject("Player Progression").AddComponent<RPGProgression>();
            GameObject player = CreatePlayer();
            PlayerController playerController = player.GetComponent<PlayerController>();
            playerController.Initialize(progression, player.transform.Find("Camera Pivot"));
            CombatSystem combat = player.AddComponent<CombatSystem>();
            combat.Initialize(progression);
            CreateCamera(player.transform.Find("Camera Pivot"));
            CreateQuestMarker(progression);
            CreateEnemies(player.transform, progression);
            RPGUI ui = new GameObject("RPG UI").AddComponent<RPGUI>();
            ui.Initialize(progression, GameObject.Find("Quest Crystal").transform);
        }

        private void CreateLighting()
        {
            RenderSettings.ambientLight = new Color(0.45f, 0.48f, 0.55f);
            RenderSettings.fog = true;
            RenderSettings.fogColor = new Color(0.18f, 0.22f, 0.28f);
            RenderSettings.fogDensity = 0.008f;
            GameObject lightObject = new GameObject("Sun");
            Light sun = lightObject.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.intensity = 1.15f;
            lightObject.transform.rotation = Quaternion.Euler(48f, -32f, 0f);
        }

        private void CreateGround()
        {
            GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "Arena Ground";
            ground.transform.position = Vector3.zero;
            ground.transform.localScale = new Vector3(arenaRadius / 5f, 1f, arenaRadius / 5f);
            ground.GetComponent<Renderer>().material = MakeMaterial(new Color(0.22f, 0.32f, 0.24f));
            CreateBoundary();
            for (int i = 0; i < 26; i++)
            {
                float angle = i * Mathf.PI * 2f / 26f;
                float radius = arenaRadius * 0.75f + (i % 3) * 1.5f;
                Vector3 position = new Vector3(Mathf.Cos(angle) * radius, 0.65f, Mathf.Sin(angle) * radius);
                GameObject rock = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                rock.name = "Arena Rock";
                rock.transform.position = position;
                rock.transform.localScale = new Vector3(1.5f + (i % 2), 1.2f, 1.4f);
                rock.GetComponent<Renderer>().material = MakeMaterial(new Color(0.28f, 0.3f, 0.34f));
            }
        }

        private void CreateBoundary()
        {
            for (int i = 0; i < 32; i++)
            {
                float angle = i * Mathf.PI * 2f / 32f;
                Vector3 position = new Vector3(Mathf.Cos(angle) * arenaRadius, 1.2f, Mathf.Sin(angle) * arenaRadius);
                GameObject pillar = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                pillar.name = "Boundary Pillar";
                pillar.transform.position = position;
                pillar.transform.localScale = new Vector3(0.9f, 1.2f, 0.9f);
                pillar.GetComponent<Renderer>().material = MakeMaterial(new Color(0.16f, 0.18f, 0.22f));
            }
        }

        private GameObject CreatePlayer()
        {
            GameObject player = new GameObject("Player");
            player.transform.position = new Vector3(0f, 1f, -5f);
            CharacterController controller = player.AddComponent<CharacterController>();
            controller.height = 2f;
            controller.radius = 0.42f;
            controller.center = new Vector3(0f, 0f, 0f);
            GameObject body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            body.name = "Player Visual";
            body.transform.SetParent(player.transform, false);
            body.transform.localPosition = Vector3.zero;
            body.transform.localScale = new Vector3(0.75f, 0.9f, 0.75f);
            Destroy(body.GetComponent<Collider>());
            body.GetComponent<Renderer>().material = MakeMaterial(new Color(0.2f, 0.55f, 0.9f));
            GameObject pivot = new GameObject("Camera Pivot");
            pivot.transform.SetParent(player.transform, false);
            pivot.transform.localPosition = new Vector3(0f, 1.1f, 0f);
            player.AddComponent<PlayerController>();
            return player;
        }

        private void CreateCamera(Transform pivot)
        {
            GameObject cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            Camera camera = cameraObject.AddComponent<Camera>();
            camera.fieldOfView = 68f;
            camera.nearClipPlane = 0.1f;
            camera.farClipPlane = 250f;
            cameraObject.AddComponent<AudioListener>();
            cameraObject.transform.SetParent(pivot, false);
            cameraObject.transform.localPosition = new Vector3(0f, GameConfig.CameraHeight - 1.1f, -GameConfig.CameraDistance);
            cameraObject.transform.localRotation = Quaternion.identity;
            CameraFollow follow = cameraObject.AddComponent<CameraFollow>();
            follow.Initialize(pivot, GameConfig.CameraDistance, GameConfig.CameraHeight);
        }

        private void CreateQuestMarker(RPGProgression progression)
        {
            GameObject crystal = GameObject.CreatePrimitive(PrimitiveType.Cube);
            crystal.name = "Quest Crystal";
            crystal.transform.position = new Vector3(0f, 1.2f, 5f);
            crystal.transform.localScale = new Vector3(1.1f, 1.6f, 1.1f);
            crystal.GetComponent<Renderer>().material = MakeMaterial(new Color(0.1f, 0.8f, 1f), true);
            Destroy(crystal.GetComponent<Collider>());
            GameObject glow = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            glow.name = "Crystal Glow";
            glow.transform.SetParent(crystal.transform, false);
            glow.transform.localScale = Vector3.one * 1.5f;
            glow.GetComponent<Renderer>().material = MakeMaterial(new Color(0.05f, 0.5f, 1f, 0.22f), true);
            Destroy(glow.GetComponent<Collider>());
        }

        private void CreateEnemies(Transform player, RPGProgression progression)
        {
            for (int i = 0; i < enemyCount; i++)
            {
                float angle = i * Mathf.PI * 2f / enemyCount;
                float radius = 7f + (i % 2) * 3f;
                Vector3 position = new Vector3(Mathf.Cos(angle) * radius, 1f, Mathf.Sin(angle) * radius);
                GameObject enemy = new GameObject("Slime " + (i + 1));
                enemy.transform.position = position;
                CharacterController controller = enemy.AddComponent<CharacterController>();
                controller.height = 1.4f;
                controller.radius = 0.55f;
                GameObject visual = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                visual.name = "Slime Visual";
                visual.transform.SetParent(enemy.transform, false);
                visual.transform.localScale = new Vector3(1.2f, 0.9f, 1.2f);
                Destroy(visual.GetComponent<Collider>());
                visual.GetComponent<Renderer>().material = MakeMaterial(new Color(0.25f, 0.78f, 0.36f));
                enemy.AddComponent<EnemyController>().Initialize(player, progression);
            }
        }

        private Material MakeMaterial(Color color, bool transparent = false)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            Material material = new Material(shader);
            material.color = color;
            if (transparent)
            {
                material.SetFloat("_Surface", 1f);
                material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                material.SetInt("_ZWrite", 0);
                material.DisableKeyword("_ALPHATEST_ON");
                material.EnableKeyword("_ALPHABLEND_ON");
                material.renderQueue = 3000;
            }
            return material;
        }
    }

    public sealed class CameraFollow : MonoBehaviour
    {
        private Transform pivot;
        private float distance;
        private float height;

        public void Initialize(Transform targetPivot, float cameraDistance, float cameraHeight)
        {
            pivot = targetPivot;
            distance = cameraDistance;
            height = cameraHeight;
        }

        private void LateUpdate()
        {
            if (pivot == null) return;
            transform.position = pivot.position - pivot.forward * distance + Vector3.up * (height - 1.1f);
            transform.LookAt(pivot.position + Vector3.up * 0.35f);
        }
    }
}
