using System;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace AshenRealms
{
    public sealed class RPGUI : MonoBehaviour
    {
        public static Action ToggleInventoryRequested;
        private RPGProgression progression;
        private Text statusText;
        private Text questText;
        private Text inventoryText;
        private GameObject inventoryPanel;
        private Transform questMarker;
        private bool inventoryOpen;

        public void Initialize(RPGProgression playerProgression, Transform marker)
        {
            progression = playerProgression;
            questMarker = marker;
            BuildUI();
            progression.Changed += Refresh;
            ToggleInventoryRequested += ToggleInventory;
            Refresh();
        }

        private void OnDestroy()
        {
            if (progression != null) progression.Changed -= Refresh;
            ToggleInventoryRequested -= ToggleInventory;
        }

        private void BuildUI()
        {
            Canvas canvas = new GameObject("RPG Canvas").AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;
            canvas.gameObject.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            canvas.GetComponent<CanvasScaler>().referenceResolution = new Vector2(1920, 1080);
            canvas.gameObject.AddComponent<GraphicRaycaster>();

            statusText = CreateText(canvas.transform, "Status", new Vector2(18, -18), new Vector2(520, 150), 22, TextAnchor.UpperLeft);
            questText = CreateText(canvas.transform, "Quest", new Vector2(-18, -18), new Vector2(480, 130), 20, TextAnchor.UpperRight);
            CreateText(canvas.transform, "Controls", new Vector2(18, 18), new Vector2(620, 90), 17, TextAnchor.LowerLeft)
                .text = "WASD Move  |  Mouse Look  |  Click/Space Attack  |  H Potion  |  I Inventory  |  E Quest";
            inventoryPanel = new GameObject("Inventory Panel", typeof(RectTransform), typeof(Image));
            inventoryPanel.transform.SetParent(canvas.transform, false);
            RectTransform panelRect = inventoryPanel.GetComponent<RectTransform>();
            panelRect.anchorMin = new Vector2(0.5f, 0.5f);
            panelRect.anchorMax = new Vector2(0.5f, 0.5f);
            panelRect.pivot = new Vector2(0.5f, 0.5f);
            panelRect.sizeDelta = new Vector2(420, 360);
            inventoryPanel.GetComponent<Image>().color = new Color(0.04f, 0.07f, 0.1f, 0.94f);
            inventoryText = CreateText(inventoryPanel.transform, "Inventory Text", new Vector2(18, -18), new Vector2(380, 320), 22, TextAnchor.UpperLeft);
            inventoryText.rectTransform.anchorMin = new Vector2(0, 1);
            inventoryText.rectTransform.anchorMax = new Vector2(0, 1);
            inventoryText.rectTransform.pivot = new Vector2(0, 1);
            inventoryPanel.SetActive(false);
        }

        private Text CreateText(Transform parent, string objectName, Vector2 offset, Vector2 size, int fontSize, TextAnchor alignment)
        {
            GameObject go = new GameObject(objectName, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(parent, false);
            RectTransform rect = go.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(offset.x < 0 ? 1 : 0, offset.y < 0 ? 1 : 0);
            rect.anchorMax = rect.anchorMin;
            rect.pivot = new Vector2(offset.x < 0 ? 1 : 0, offset.y < 0 ? 1 : 0);
            rect.anchoredPosition = offset;
            rect.sizeDelta = size;
            Text text = go.GetComponent<Text>();
            text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.fontSize = fontSize;
            text.alignment = alignment;
            text.color = Color.white;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            return text;
        }

        private void Update()
        {
            if (progression == null) return;
            if (Input.GetKeyDown(KeyCode.E) && questMarker != null &&
                Vector3.Distance(Camera.main.transform.position, questMarker.position) < 12f)
            {
                progression.ClaimQuestReward();
            }
        }

        private void ToggleInventory()
        {
            inventoryOpen = !inventoryOpen;
            if (inventoryPanel != null) inventoryPanel.SetActive(inventoryOpen);
            if (inventoryOpen) Refresh();
        }

        private void Refresh()
        {
            if (progression == null) return;
            statusText.text =
                GameConfig.GameTitle + "\n" +
                "Level " + progression.Level + "   XP " + progression.CurrentXP + "/" + progression.XPToNextLevel + "\n" +
                "HP " + Mathf.CeilToInt(progression.CurrentHealth) + "/" + Mathf.CeilToInt(progression.MaxHealth) + "\n" +
                "Gold " + progression.Gold + "   Potions " + progression.Potions;
            string questState = progression.QuestRewardClaimed ? "Reward claimed" :
                progression.QuestComplete ? "Return to the crystal and press E" :
                "Defeat slimes: " + progression.SlimesDefeated + "/" + GameConfig.QuestSlimeGoal;
            questText.text = "QUEST: Slime Trouble\n" + questState;
            if (inventoryText != null)
            {
                StringBuilder builder = new StringBuilder();
                builder.AppendLine("INVENTORY");
                builder.AppendLine("Potions: " + progression.Potions + " (press H to drink)");
                foreach (var item in progression.Inventory)
                    builder.AppendLine(item.Key + ": " + item.Value);
                builder.AppendLine();
                builder.AppendLine("Press I to close");
                inventoryText.text = builder.ToString();
            }
        }
    }
}
