using UnityEngine;

namespace AshenRealms
{
    public interface IDamageable
    {
        bool IsAlive { get; }
        void TakeDamage(float amount, GameObject source);
    }

    public sealed class CombatSystem : MonoBehaviour
    {
        private RPGProgression progression;
        private float nextAttackTime;
        private Animator animator;

        public void Initialize(RPGProgression playerProgression)
        {
            progression = playerProgression;
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.I) && progression != null)
            {
                // Inventory visibility is handled by RPGUI.
                RPGUI.ToggleInventoryRequested?.Invoke();
            }

            if ((Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space)) &&
                Time.time >= nextAttackTime && Cursor.lockState == CursorLockMode.Locked)
            {
                Attack();
            }

            if (Input.GetKeyDown(KeyCode.H) && progression != null)
                progression.UsePotion();
        }

        private void Attack()
        {
            nextAttackTime = Time.time + GameConfig.PlayerAttackCooldown;
            Vector3 origin = transform.position + Vector3.up * 1.0f;
            Vector3 direction = transform.forward;
            if (Physics.SphereCast(origin, 0.45f, direction, out RaycastHit hit,
                    GameConfig.PlayerAttackRange, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore))
            {
                IDamageable target = hit.collider.GetComponentInParent<IDamageable>();
                if (target != null && target.IsAlive)
                    target.TakeDamage(GameConfig.PlayerAttackDamage + (progression.Level - 1) * 5f, gameObject);
            }
        }
    }
}
